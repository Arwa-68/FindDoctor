﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class Manage_AddDoctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["ID"] != null)
            {
                DirDept(int.Parse(Request.QueryString["ID"]));
            }
        }
    }

    private void DirDept(int ID)
    {
        DataClassesDataContext DB = new DataClassesDataContext();
        Doctor doc = DB.Doctors.Single(p => p.DoctorID == ID);
        Departmenttxt.Text = doc.DoctorName;
        MobileNumber.Text = doc.DoctorMobile;
        TelNumber.Text = doc.DoctorTel;
        spec.SelectedValue = doc.DoctorSpecialisID.ToString();
        HospitalID.SelectedValue = doc.HospialID.ToString();
    }

    protected void Unnamed_Click(object sender, EventArgs e)
    {

        DataClassesDataContext DB = new DataClassesDataContext();
        Doctor dept = new Doctor();
        if (Request.QueryString["ID"] != null)
            dept = DB.Doctors.Single(p => p.DoctorID == int.Parse(Request.QueryString["ID"]));

        dept.DoctorName = Departmenttxt.Text;
        dept.DoctorMobile = MobileNumber.Text;
        dept.DoctorTel = TelNumber.Text;
        dept.DoctorSpecialisID = int.Parse(spec.SelectedValue);
        dept.HospialID = int.Parse(HospitalID.SelectedValue);
        foreach (UploadedFile file in Upload1.UploadedFiles)
        {

            string gi = Guid.NewGuid().ToString();
            file.SaveAs(Server.MapPath("..") + @"\Upload\Doctors\" + gi + file.GetExtension());
            gi = gi + file.GetExtension();
            dept.Image = gi;
        }
        if (Request.QueryString["ID"] == null)
            DB.Doctors.InsertOnSubmit(dept);
        DB.SubmitChanges();
        Response.Redirect("Doctorsfrm.aspx");
    }

    protected void Unnamed_ServerClick(object sender, EventArgs e)
    {
        Response.Redirect("Doctorsfrm.aspx");
    }

    protected void Unnamed_Click1(object sender, EventArgs e)
    {

    }
}